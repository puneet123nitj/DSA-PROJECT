
#include<stdio.h>
void compreorder(int tree[],int n,int k);
void cominorder(int tree[],int n,int k);
void compostorder(int tree[],int n,int k);
complete()
{int n,i,j,data,data2;
printf("enter the number of nodes\n");
scanf("%d",&n);



int tree[n+1];
for(i=1;i<=n;i++)
scanf("%d",&tree[i]);
printf("\n\n");

for(i=1;i<=n;i++)
        printf("%d\n",tree[i]);
        printf("\n\n");
printf("preordre\n");
compreorder(tree,n,1);
printf("\n");
printf("compostorder\n");
compostorder(tree,n,1);
printf("\n");
printf("cominorder\n");
cominorder(tree,n,1);
printf("the number whose ancestors required\n");
scanf("%d",&data);
for(j=1;j<=n+1;j++)
{if(tree[j]==data)
     break;}

while(j!=1)
{j=j/2;
printf("%d\n",tree[j]);


}
printf("the data whose decentent required\n");
scanf("%d",&data2);
for(i=1;i<=n+1;i++)
{if(tree[i]==data);
  break;}
  compreorder(tree,n,i);

system("pause");
   system("cls");
   tree1();
}
void compreorder(int tree[],int n,int k)
{if(k>n)
return;
if(tree[k]>1000)
   return;
    else
    {printf("%d\n",tree[k]);}
  compreorder(tree,n,2*k);
  compreorder(tree,n,2*k+1);
    }
    void cominorder(int tree[],int n,int k)
{if(k>n)
return;

if(tree[k]>1000)
   return;
  cominorder(tree,n,2*k);
  if(tree[k]<=1000)
  printf("%d\n",tree[k]);
  cominorder(tree,n,2*k+1);
    }
    void compostorder(int tree[],int n,int k)
{if(k>n)
return;
if(tree[k]>1000)
    return;
   compostorder(tree,n,2*k);
  compostorder(tree,n,2*k+1);
  if(tree[k]<=1000)
  printf("%d\n",tree[k]);}
