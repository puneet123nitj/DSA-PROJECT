
#include<stdio.h>
#include<stdlib.h>

struct cqueue
{
	int info;
	struct cqueue *link;
}*cqlrear=NULL;

void cqlinsert(int item);
int cqldel();
void cqldisplay();
int cqlisEmpty();
int cqlpeek();

cqlink()
{
	int choice,item;
	while(1)
	{
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Peek\n");
		printf("4.Display\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		 case 1:
			printf("Enter the element for insertion : ");
			scanf("%d",&item);
			cqlinsert(item);
			break;
		 case 2:
			printf("Deleted element is %d\n",cqldel());
			break;
		 case 3:
			printf("Item at the front of cqueue is %d\n",cqlpeek());
			break;
		 case 4:
			cqldisplay();
			break;
		 case 5:
			queue1();
			break;
		 default:
			printf("Wrong choice\n");
		}system("pause");
   system("cls");}}
void cqlinsert(int item)
{
	struct cqueue *tmp;
	tmp=(struct cqueue *)malloc(sizeof(struct cqueue));
	tmp->info=item;
	if(tmp==NULL)
	{
		printf("Memory not available\n");
		return;
	}

	if( cqlisEmpty() ) /*If cqueue is empty */
	{
		cqlrear=tmp;
		tmp->link=cqlrear;
	}
	else
	{
		tmp->link=cqlrear->link;
		cqlrear->link=tmp;
		cqlrear=tmp;
	}
}/*End of insert()*/

cqldel()
{
	int item;
	struct cqueue *tmp;
	if( cqlisEmpty() )
	{
		printf("cqueue underflow\n");
		cqlink();
	}
	if(cqlrear->link==cqlrear)  /*If only one element*/
	{
		tmp=cqlrear;
		cqlrear=NULL;
	}
	else
	{
		tmp=cqlrear->link;
		cqlrear->link=cqlrear->link->link;
	}
	item=tmp->info;
	free(tmp);
	return item;
}/*End of del()*/

int cqlpeek()
{
	if( cqlisEmpty() )
	{
		printf("cqueue underflow\n");
		cqlink();
	}
	return cqlrear->link->info;
}/* End of peek() */

int cqlisEmpty()
{
	if( cqlrear == NULL )
		return 1;
	else
		return 0;
}/*End of isEmpty()*/


void cqldisplay()
{
	struct cqueue *p;
	if(cqlisEmpty())
	{
		printf("cqueue is empty\n");
		return;
	}
	printf("cqueue is :\n");
	p=cqlrear->link;
	do
	{
		printf("%d ",p->info);
		p=p->link;
	}while(p!=cqlrear->link);
	printf("\n");
}/*End of display()*/


