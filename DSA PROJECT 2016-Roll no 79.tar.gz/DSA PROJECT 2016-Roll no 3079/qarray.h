
#include<stdio.h>
#include<stdlib.h>
#define MAX 10

int queue_arr[MAX];
int qrear=-1;
int qfrontt=-1;

void qinsert(int item);
int qdel();
int qpeek();
void qdisplay();
int qisFull();
int qisEmpty();

q()
{
	int choice,item;
	while(1)
	{
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Display element at the qfrontt\n");
		printf("4.Display all elements of the queue\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:
			printf("Input the element for adding in queue : ");
			scanf("%d",&item);
			qinsert(item);
			break;
		case 2:
			item=qdel();
			printf("Deleted element is  %d\n",item);
			break;
		case 3:
			printf("Element at the qfrontt is %d\n",qpeek());
			break;
		case 4:
			qdisplay();
			break;
		case 5:
			queue1();
			break;
		default:
			printf("Wrong choice\n");
		}system("pause");
   system("cls");
	}}
void qinsert(int item)
{
	if( qisFull() )
	{
		printf("Queue Overflow\n");
		return;
	}
	if( qfrontt == -1 )
		qfrontt=0;
	qrear=qrear+1;
	queue_arr[qrear]=item ;
}/*End of insert()*/

int qdel()
{
	int item;
	if( qisEmpty() )
	{
		printf("Queue Underflow\n");
		q();
	}
	item=queue_arr[qfrontt];
	qfrontt=qfrontt+1;
	return item;
}/*End of del()*/

int qpeek()
{
	if( qisEmpty() )
	{
		printf("Queue Underflow\n");
		q();
	}
	return queue_arr[qfrontt];
}/*End of peek()*/

int qisEmpty()
{
	if( qfrontt==-1 || qfrontt==qrear+1 )
		return 1;
	else
		return 0;
}/*End of isEmpty()*/

int qisFull()
{
	if( qrear==MAX-1 )
		return 1;
	else
		return 0;
}/*End of isFull()*/

void qdisplay()
{
	int i;
	if ( qisEmpty() )
	{
		printf("Queue is empty\n");
		return;
	}
	printf("Queue is :\n\n");
	for(i=qfrontt;i<=qrear;i++)
		printf("%d  ",queue_arr[i]);
	printf("\n\n");
}/*End of display() */
