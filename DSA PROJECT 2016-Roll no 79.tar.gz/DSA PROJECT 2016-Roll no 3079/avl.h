#include <stdio.h>
#include <stdlib.h>
#define STOP getchar()
#define FALSE 0
#define TRUE 1
struct AVL
{
	struct  AVL *lchild;
	int info;
	struct  AVL *rchild;
	int balance;
};

void AVLinorder(struct AVL *ptr);
void AVLdisplay(struct AVL *ptr,int level);
struct AVL *RotateLeft(struct AVL *pptr);
struct AVL *RotateRight(struct AVL *pptr);
struct AVL *AVLinsert(struct AVL *pptr, int ikey);
struct AVL *insert_left_check(struct AVL *pptr, int *ptaller);
struct AVL *insert_right_check(struct AVL *pptr, int *ptaller);
struct AVL *insert_LeftBalance(struct AVL *pptr);
struct AVL *insert_RightBalance(struct AVL *pptr);
struct AVL *AVLdel(struct AVL *pptr, int dkey);
struct AVL *del_left_check(struct AVL *pptr, int *pshorter);
struct AVL *del_right_check(struct AVL *pptr, int *pshorter);
struct AVL *del_LeftBalance(struct AVL *pptr, int *pshorter);
struct AVL *del_RightBalance(struct AVL *pptr, int *pshorter);

AVL()
{
	int choice,k;
	struct AVL *root = NULL;
    while(1)
	{
		printf("\n");
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Inorder Traversal\n");
		printf("4.Display\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		 case 1:
			AVLdisplay(root,0); printf("\n\n");
			printf("Enter the number to be inserted : ");
			scanf("%d",&k);
			if(root!=NULL)
				printf("\nPath is ");
			root = AVLinsert(root,k);
			AVLdisplay(root,0); printf("\n\n");
			break;
		 case 2:
			AVLdisplay(root,0); printf("\n\n");
			printf("Enter the number to be deleted : ");
			scanf("%d",&k);
			if(root->info!=k)
				printf("\nPath is ");
			root = AVLdel(root,k);
			AVLdisplay(root,0); printf("\n\n");
			break;
		 case 3:
			AVLinorder(root);
			break;
		 case 4:
			AVLdisplay(root,0);printf("\n\n");
			break;
		 case 5:
			tree1();
			break;
		 default:
			printf("Wrong choice\n");
		}
		system("pause");
   system("cls");
	}
}

struct AVL *AVLinsert(struct AVL *pptr, int ikey)
{
	static int taller;
	if(pptr==NULL)
	{
		pptr = (struct AVL *) malloc(sizeof(struct AVL));
		pptr->info = ikey;
		pptr->lchild = NULL;
		pptr->rchild = NULL;
		pptr->balance = 0;
		taller = TRUE;
		STOP;
		printf("\n\nNew AVL with info = %d inserted, taller = TRUE ", ikey);
		STOP;
		printf("Unwinding Phase starts\n");
	}
	else if(ikey < pptr->info)	/*Insertion in left subtree*/
	{
		printf(" --> %d",pptr->info);
		pptr->lchild = AVLinsert(pptr->lchild, ikey);
		if(taller==TRUE)
		{
			printf("\nCheck AVL %d   ", pptr->info);
			STOP;
			pptr = insert_left_check( pptr, &taller );
		}
	}
	else if(ikey > pptr->info)	/*Insertion in right subtree */
	{
		printf(" --> %d",pptr->info);
		pptr->rchild = AVLinsert(pptr->rchild, ikey);
		if(taller==TRUE)
		{
			printf("\nCheck AVL %d   ", pptr->info);
			STOP;
			pptr = insert_right_check(pptr, &taller);
		}
	}
	else  /*Base Case*/
	{
		printf("\nDuplicate key, taller = FALSE\n");
		printf("Unwinding Phase starts\n");
		taller = FALSE;
	}
	return(pptr);
}/*End of insert( )*/

struct AVL *insert_left_check(struct AVL *pptr, int *ptaller )
{
	switch(pptr->balance)
	{
	 case 0: /* Case L_A : was balanced */
		 printf("Case L_A : was balanced now left heavy\n");
		 pptr->balance = 1;	/* now left heavy */
		break;
	 case -1: /* Case L_B: was right heavy */
		 printf("Case L_B : was right heavy now balanced\n");
		 pptr->balance = 0;	/* now balanced */
		*ptaller = FALSE;
		printf("taller becomes false, Stop checking\n");
		break;
	 case 1: /* Case L_C: was left heavy */
		printf("Case L_C : was left heavy now unbalanced, left Balancing required\n");
		printf("AVL %d becomes pivot AVL\n",pptr->info);
		pptr = insert_LeftBalance(pptr);	/* Left Balancing */
		*ptaller = FALSE;
		printf("taller becomes false, Stop checking\n");
	}
	return pptr;
}/*End of insert_left_check( )*/

struct AVL *insert_right_check(struct AVL *pptr, int *ptaller )
{
	switch(pptr->balance)
	{
	 case 0: /* Case R_A : was balanced */
		printf("Case R_A : was balanced now right heavy\n");
		pptr->balance = -1;	/* now right heavy */
		break;
	 case 1: /* Case R_B : was left heavy */
		printf("Case L_B : was left heavy now balanced\n");
		 pptr->balance = 0;	/* now balanced */
		*ptaller = FALSE;
		printf("taller becomes false, Stop checking\n");
		break;
	 case -1: /* Case R_C: Right heavy */
		printf("Case R_C : was right heavy now unbalanced, right Balancing required\n");
		printf("AVL %d becomes pivot AVL\n",pptr->info);
		pptr = insert_RightBalance(pptr);	/* Right Balancing */
		*ptaller = FALSE;
		printf("taller becomes false, Stop checking\n");
	}
	return pptr;
}/*End of insert_right_check( )*/

struct AVL *insert_LeftBalance(struct AVL *pptr)
{
	struct AVL *aptr, *bptr;

	aptr = pptr->lchild;
	if(aptr->balance == 1)  /* Case L_C1 : Insertion in AL */
	{
		printf("Case L_C1\n");
		pptr->balance = 0;
		aptr->balance = 0;
		pptr = RotateRight(pptr);
	}
	else		/* Case L_C2 : Insertion in AR */
	{
		bptr = aptr->rchild;
		switch(bptr->balance)
		{
		case -1:			/* Case L_C2a : Insertion in BR */
			printf("Case L_C2a\n");
			pptr->balance = 0;
			aptr->balance = 1;
			break;
		case 1:					/* Case L_C2b : Insertion in BL */
			printf("Case L_C2b\n");
			pptr->balance = -1;
			aptr->balance = 0;
			break;
		case 0:					/* Case L_C2c : B is the newly inserted AVL */
			printf("Case L_C2c\n");
			pptr->balance = 0;
			aptr->balance = 0;
		}
		bptr->balance = 0;
		pptr->lchild = RotateLeft(aptr);
		pptr = RotateRight(pptr);
	}
	return pptr;
}/*End of insert_LeftBalance( )*/

struct AVL *insert_RightBalance(struct AVL *pptr)
{
	struct AVL *aptr, *bptr;

	aptr = pptr->rchild;
	if(aptr->balance == -1) /* Case R_C1 : Insertion in AR */
	{
		printf("Case R_C1\n");
		pptr->balance = 0;
		aptr->balance = 0;
		pptr = RotateLeft(pptr);
	}
	else		/* Case R_C2 : Insertion in AL */
	{
		bptr = aptr->lchild;
		switch(bptr->balance)
		{
		case -1:	/* Case R_C2a : Insertion in BR */
			printf("Case R_C2a\n");
			pptr->balance = 1;
			aptr->balance = 0;
			break;
		case 1:		/* Case R_C2b : Insertion in BL */
			printf("Case R_C2b\n");
			pptr->balance = 0;
			aptr->balance = -1;
			break;
		case 0:		/* Case R_C2c : B is the newly inserted AVL */
			printf("Case R_C2c\n");
			pptr->balance = 0;
			aptr->balance = 0;
		}
		bptr->balance = 0;
		pptr->rchild = RotateRight(aptr);
		pptr = RotateLeft(pptr);
	}
	return pptr;
}/*End of insert_RightBalance( )*/

struct AVL *RotateLeft(struct AVL *pptr)
{
	struct AVL *aptr;
	printf("Rotate left about %d\n",pptr->info);
	aptr = pptr->rchild;	/*A is right child of P*/
	pptr->rchild = aptr->lchild; /*Left child of A becomes right child of P */
	aptr->lchild = pptr;  /*P becomes left child of A*/
	return aptr;  /*A is the new root of the subtree initially rooted at P*/
}/*End of RotateLeft( )*/

struct AVL *RotateRight(struct AVL *pptr)
{
	struct AVL *aptr;
	printf("Rotate Right about %d\n",pptr->info);
	aptr = pptr->lchild;	/*A is left child of P */
	pptr->lchild = aptr->rchild; /*Right child of A becomes left child of P*/
	aptr->rchild = pptr;			/*P becomes right child of A*/
	return aptr; /*A is the new root of the subtree initially rooted at P*/
}/*End of RotateRight( )*/

struct AVL *AVLdel(struct AVL *pptr, int dkey)
{
	struct AVL *tmp, *succ;
	static int shorter;

	if( pptr == NULL) /*Base Case*/
	{
		printf("\nKey not present, shorter = FALSE\n");
		printf("Unwinding Phase begins\n");
		shorter = FALSE;
		return(pptr);
	}
	if( dkey < pptr->info )
	{
		printf(" --> %d",pptr->info);
		pptr->lchild = AVLdel(pptr->lchild, dkey);
		if(shorter == TRUE)
		{
			printf("Check AVL %d \n",pptr->info);
			STOP;
			pptr = del_left_check(pptr, &shorter);
			STOP;
		}
	}
	else if( dkey > pptr->info )
	{
		printf(" --> %d",pptr->info);
		pptr->rchild = AVLdel(pptr->rchild, dkey);
		if(shorter==TRUE)
		{
			printf("Check AVL %d \n",pptr->info);
			STOP;
			pptr = del_right_check(pptr, &shorter);
			STOP;
		}
	}
	else /* dkey == pptr->info, Base Case*/
	{
		printf("\n");
		/*pptr has 2 children*/
		if( pptr->lchild!=NULL  &&  pptr->rchild!=NULL )
		{
			succ = pptr->rchild;
			while(succ->lchild)
				succ = succ->lchild;
			printf("Successor of AVL %d is AVL %d\n", pptr->info, succ->info);
			printf("Info part of AVL %d is changed to %d and the successor AVL is deleted\n", pptr->info, succ->info);
			pptr->info = succ->info;

			if( pptr->rchild->info != succ->info )
				printf("Path is ");

			pptr->rchild = AVLdel(pptr->rchild, succ->info);
			if( shorter == TRUE )
			{
				printf("Check AVL %d \n",pptr->info);
				pptr = del_right_check(pptr, &shorter);
				STOP;
			}
		}
		else
		{
			tmp = pptr;
			if( pptr->lchild != NULL ) /*only left child*/
				pptr = pptr->lchild;
			else if( pptr->rchild != NULL) /*only right child*/
				pptr = pptr->rchild;
			else	/* no children */
				pptr = NULL;
			free(tmp);
			shorter = TRUE;
			printf("AVL deleted, shorter = TRUE\n");
		}
	}
	return pptr;
}/*End of del( )*/

struct AVL *del_left_check(struct AVL *pptr, int *pshorter)
{
	switch(pptr->balance)
	{
		case 0: /* Case L_A : was balanced */
			printf("Case L_A, was balanced, now right heavy\n");
			pptr->balance = -1;	/* now right heavy */
			*pshorter = FALSE;
			printf("shorter = FALSE, stop checking\n");
			break;
		case 1: /* Case L_B : was left heavy */
			printf("Case L_B, was left heavy, now balanced\n");
			pptr->balance = 0;	/* now balanced */
			break;
		case -1: /* Case L_C : was right heavy */
			printf("Case L_C, was right heavy, now unbalanced, Right balancing required\n");
			printf("Pivot AVL is %d\n",pptr->info);
			pptr = del_RightBalance(pptr, pshorter); /*Right Balancing*/
	}
	return pptr;
}/*End of del_left_check( )*/

struct AVL *del_right_check(struct AVL *pptr, int *pshorter)
{
	switch(pptr->balance)
	{
		case 0:		/* Case R_A : was balanced */
			printf("Case R_A, was balanced, now left heavy\n");
			pptr->balance = 1;	/* now left heavy */
			*pshorter = FALSE;
			printf("shorter = FALSE, stop checking\n");
			break;
		case -1: /* Case R_B : was right heavy */
			printf("Case R_B, was right heavy, now balanced\n");
			pptr->balance = 0;	/* now balanced */
			break;
		case 1: /* Case R_C : was left heavy */
			printf("Case R_C, was left heavy, now unbalanced, Left balancing required\n");
			printf("Pivot AVL is %d\n",pptr->info);
			pptr = del_LeftBalance(pptr, pshorter );  /* Left Balancing */
	}
	return pptr;
}/*End of del_right_check( )*/

struct AVL *del_LeftBalance(struct AVL *pptr,int *pshorter)
{
	struct AVL *aptr, *bptr;
	aptr = pptr->lchild;
	if( aptr->balance == 0)  /* Case R_C1 */
	{
		printf("Case R_C1\n");
		pptr->balance = 1;
		aptr->balance = -1;
		*pshorter = FALSE;
		pptr = RotateRight(pptr);
		printf("shorter = FALSE, stop checking\n");
	}
	else if(aptr->balance == 1 ) /* Case R_C2 */
	{
		printf("Case R_C2\n");
		pptr->balance = 0;
		aptr->balance = 0;
		pptr = RotateRight(pptr);
	}
	else						/* Case R_C3 */
	{
		bptr = aptr->rchild;
		switch(bptr->balance)
		{
			case 0:					/* Case R_C3a */
				printf("Case R_C3a\n");
				pptr->balance = 0;
				aptr->balance = 0;
				break;
			case 1:					/* Case R_C3b */
				printf("Case R_C3b\n");
				pptr->balance = -1;
				aptr->balance = 0;
				break;
			case -1:			/* Case R_C3c */
				printf("Case R_C3c\n");
				pptr->balance = 0;
				aptr->balance = 1;
		}
		bptr->balance = 0;
		pptr->lchild = RotateLeft(aptr);
		pptr = RotateRight(pptr);
	}
	return pptr;
}/*End of del_LeftBalance( )*/
struct AVL *del_RightBalance(struct AVL *pptr,int *pshorter)
{
	struct AVL *aptr, *bptr;

	aptr = pptr->rchild;
	if (aptr->balance == 0)	/* Case L_C1 */
	{
		printf("Case L_C1\n");
		pptr->balance = -1;
		aptr->balance = 1;
		*pshorter = FALSE;
		pptr = RotateLeft(pptr);
		printf("shorter = FALSE, stop checking\n");
	}
	else if(aptr->balance == -1 )	/* Case L_C2 */
	{
		printf("Case L_C2\n");
		pptr->balance = 0;
		aptr->balance = 0;
		pptr = RotateLeft(pptr);
	}
	else							/* Case L_C3 */
	{
		bptr = aptr->lchild;
		switch(bptr->balance)
		{
			case 0:					/* Case L_C3a */
				printf("Case L_C3a\n");
				pptr->balance = 0;
				aptr->balance = 0;
				break;
			case 1:					/* Case L_C3b */
				printf("Case L_C3b\n");
				pptr->balance = 0;
				aptr->balance = -1;
				break;
			case -1:				/* Case L_C3c */
				printf("Case L_C3c\n");
				pptr->balance = 1;
				aptr->balance = 0;
		}
		bptr->balance = 0;
		pptr->rchild = RotateRight(aptr);
		pptr = RotateLeft(pptr);
	}
	return pptr;
}/*End of del_RightBalance( )*/

void AVLinorder(struct AVL *ptr)
{
	if(ptr!=NULL)
	{
		AVLinorder(ptr->lchild);
		printf("%d  ",ptr->info);
		AVLinorder(ptr->rchild);
	}
}/*End of inorder()*/

void AVLdisplay(struct AVL *ptr,int level)
{
	int i;
	if(ptr!=NULL)
	{
		AVLdisplay(ptr->rchild, level+1);
		printf("\n");
		for (i = 0; i < level; i++)
			printf("    ");
		printf("%d", ptr->info);
		if(ptr->balance == 1)
			printf("+");
		else if(ptr->balance == -1)
			printf("-");
		else
			printf("*");
		AVLdisplay(ptr->lchild, level+1);
	}
}/*End of display()*/



