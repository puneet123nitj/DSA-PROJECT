#include<stdio.h>
list1()
{int choicelink;
while(1)
{
printf("1-> for single link list\n") ;
printf("2-> for double link list\n");
printf("3-> for circular link list\n");
printf("4-> for another option\n");
printf("enter your choice =");
scanf("%d",&choicelink);
switch(choicelink)
{
case 1:
    slink();
    break;
case 2:
    dlink();
    break;
case 3:
    clink();
    break;
case 4:
    main();
    break;}
    system("pause");
    system("cls");}}
