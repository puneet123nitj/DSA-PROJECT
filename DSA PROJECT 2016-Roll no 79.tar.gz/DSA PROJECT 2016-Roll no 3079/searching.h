#include<stdio.h>
search1()
{int choicesearch;
while(1)
{
printf("1-> for linear search\n") ;
printf("2-> for binary search\n");
printf("3-> for fibonacci search\n");
printf("4-> for another option\n");
printf("enter your choice =");
scanf("%d",&choicesearch);
switch(choicesearch)
{
case 1:
    linear();
    break;
case 2:
    binary();
    break;
case 3:
    fibonacci();
    break;
case 4:
    main();
    break;}
    system("pause");
    system("cls");}}

