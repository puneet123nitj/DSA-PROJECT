#include<stdio.h>
selection()
{
int min,n,i,j,swap;
printf("enter the size of array\n");
scanf("%d",&n);
int ar[n];
printf("enter the elements of array\n");
for(i=0;i<n;i++)
    scanf("%d",&ar[i]);
for(i=0;i<n-1;i++)
{min=i;
for(j=i+1;j<n;j++)
{if(ar[min]>ar[j])
    {min=j;}}
if(i!=min)
{swap=ar[min];
ar[min]=ar[i];
ar[i]=swap;
}
}
for(i=0;i<n;i++)
{printf("%d\n",ar[i]);

}
system("pause");
   system("cls");
   sort1();
}
