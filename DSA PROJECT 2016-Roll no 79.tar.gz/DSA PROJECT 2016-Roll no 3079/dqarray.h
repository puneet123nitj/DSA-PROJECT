
#include<stdio.h>
#include<stdlib.h>
#define MAX 7

int deque_arr[MAX];
int dfront=-1;
int drear=-1;

void dqinsert_dfrontEnd(int item);
void dqinsert_drearEnd(int item);
int dqdelete_dfrontEnd();
int dqdelete_drearEnd();
void dqdisplay();
int dqisEmpty();
int dqisFull();

dq()
{
	int choice,item;
	while(1)
	{
		printf("1.Insert at the dfront end\n");
		printf("2.Insert at the drear end\n");
		printf("3.Delete from dfront end\n");
		printf("4.Delete from drear end\n");
		printf("5.Display\n");
		printf("6.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:
			printf("Input the element for adding in dqueue : ");
			scanf("%d",&item);
			dqinsert_dfrontEnd(item);
			break;
		case 2:
			printf("Input the element for adding in dqueue : ");
			scanf("%d",&item);
			dqinsert_drearEnd(item);
			break;
		 case 3:
			printf("Element deleted from dfront end is : %d\n",dqdelete_dfrontEnd());
			break;
		 case 4:
			printf("Element deleted from drear end is : %d\n",dqdelete_drearEnd());
			break;
		 case 5:
			dqdisplay();
			break;
		 case 6:
			queue1();
			break;
		 default:
			printf("Wrong choice\n");
		}/*End of switch*/
		printf("dfront = %d, drear =%d\n", dfront , drear);
		dqdisplay();
		system("pause");
   system("cls");
	}}

void dqinsert_dfrontEnd(int item)
{
	if( dqisFull() )
	{
		printf("dqueue Overflow\n");
		return;
	}
	if( dfront==-1 )/*If dqueue is initially empty*/
	{
		dfront=0;
		drear=0;
	}
	else if(dfront==0)
		dfront=MAX-1;
	else
		dfront=dfront-1;
	deque_arr[dfront]=item ;
}/*End of insert_dfrontEnd()*/

void dqinsert_drearEnd(int item)
{
	if( dqisFull() )
	{
		printf("dqueue Overflow\n");
		return;
	}
	if(dfront==-1)  /*if dqueue is initially empty*/
	{
		dfront=0;
		drear=0;
	}
	else if(drear==MAX-1)  /*drear is at last position of dqueue */
		drear=0;
	else
		drear=drear+1;
	deque_arr[drear]=item ;
}/*End of insert_drearEnd()*/

int dqdelete_dfrontEnd()
{
	int item;
	if( dqisEmpty() )
	{
		printf("dqueue Underflow\n");
		dq();
	}
	item=deque_arr[dfront];
	if(dfront==drear) /*dqueue has only one element */
	{
		dfront=-1;
		drear=-1;
	}
	else
		if(dfront==MAX-1)
			dfront=0;
		else
			dfront=dfront+1;
	return item;
}/*End of delete_dfrontEnd()*/

int dqdelete_drearEnd()
{
	int item;
	if( dqisEmpty() )
	{
		printf("dqueue Underflow\n");
		dq();
	}
	item=deque_arr[drear];

	if(dfront==drear) /*dqueue has only one element*/
	{
		dfront=-1;
		drear=-1;
	}
	else if(drear==0)
		drear=MAX-1;
	else
		drear=drear-1;
	return item;
}/*End of delete_drearEnd() */

int dqisFull()
{
	if ( (dfront==0 && drear==MAX-1) || (dfront==drear+1) )
		return 1;
	else
		return 0;
}/*End of isFull()*/

int dqisEmpty()
{
	if( dfront == -1)
		return 1;
	else
		return 0;
}/*End of isEmpty()*/

void dqdisplay()
{
	int i;
	if( dqisEmpty() )
	{
		printf("dqueue is empty\n");
		return;
	}
	printf("dqueue elements :\n");
	i=dfront;
	if( dfront<=drear )
	{
		while(i<=drear)
			printf("%d ",deque_arr[i++]);
	}
	else
	{
		while(i<=MAX-1)
			printf("%d ",deque_arr[i++]);
		i=0;
		while(i<=drear)
			printf("%d ",deque_arr[i++]);
	}
	printf("\n");
}/*End of display() */




