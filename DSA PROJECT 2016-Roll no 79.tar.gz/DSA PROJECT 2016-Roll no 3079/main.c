#include <stdio.h>
#include "deco.h"
#include "single.h"
#include "double.h"
#include "circular.h"
#include "cqlink.h"
#include "dqarray.h"
#include "stackarray.h"
#include "stacklink.h"
#include "qarray.h"
#include "linear.h"
#include "fibonacci.h"
#include "binary.h"
#include "cqarray.h"
#include "qlink.h"
#include "merge.h"
#include "quick.h"
#include "selection.h"
#include "insertion.h"
#include "bubble.h"
#include "avl.h"
#include "last.h"
#include "heaptree.h"
#include  "heapsort.h"
#include "exptree.h"
#include "thereded.h"
#include "completebt.h"
#include "list.h"
#include "bst.h"
#include "sorting.h"
#include "stack.h"
#include "queue.h"
#include "polishnotation.h"
#include "searching.h"
#include "tree.h"
#include "twostack.h"
#include "myvector.h"
int main()
{int choice;
   index();
while(choice)
  {
  printf("1-> for all type of link list\n");
  printf("2-> for all type of stack\n");
  printf("3-> for all type of queue\n");
  printf("4-> for all type of sorting technique\n");
  printf("5-> for all type of searching technique\n");
  printf("6-> for all type of tree\n");
  printf("7->for vector operation\n");
  printf("8-> for quit\n");
  printf("enter your choice:\n");
  scanf("%d",&choice);
  switch(choice)
   {case 1:
       list1();
       break;
   case 2:
    stack1();
      break;
   case 3:
    queue1();
    break;
   case 4:
    sort1();
    break;
   case 5:
    search1();
    break;
   case 6:
    tree1();
    break;
   case 7:
    vector1();
    break;
   case 8:
    last();

}
system("pause");
system("cls");
}
}
