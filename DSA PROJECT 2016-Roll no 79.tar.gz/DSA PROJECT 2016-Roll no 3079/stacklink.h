

#include<stdio.h>
#include<stdlib.h>

struct stack
{
	int info;
	struct stack *link;
}*sltop=NULL;

void slpush(int item);
int slpop();
int slpeek();
int slisEmpty();
void sldisplay();

s1link()
{
	int choice,item;
	while(1)
	{
		printf("1.Push\n");
		printf("2.Pop\n");
		printf("3.Display item at the sltop\n");
		printf("4.Display all items of the stack\n");
		printf("5.for another option\n");
		printf("Enter your choice : ") ;
		scanf("%d", &choice);

		switch(choice)
		{
		case 1:
			printf("Enter the item to be pushed : ");
			scanf("%d",&item);
			slpush(item);
			break;
		case 2:
			item=slpop();
			printf("Popped item is : %d\n",item);
			break;
		case 3:
			printf("Item at the sltop is %d\n",slpeek());
			break;
		case 4:
			sldisplay();
			break;
		case 5:
			stack1();
			break;
		default :
			printf("Wrong choice\n");
		}system("pause");
   system("cls");}}
void slpush(int item)
{
	struct stack *tmp;
	tmp=(struct stack *)malloc(sizeof(struct stack));
	if(tmp==NULL)
	{
		printf("Stack Overflow\n");
		return;
	}
	tmp->info=item;
	tmp->link=sltop;
	sltop=tmp;
}/*End of push()*/

int slpop()
{
	struct stack *tmp;
	int item;
	if( slisEmpty() )
	{
		printf("Stack Underflow\n");
		slink();
	}
	tmp=sltop;
	item=tmp->info;
	sltop=sltop->link;
	free(tmp);
	return item;
}/*End of pop()*/

int slpeek()
{
	if( slisEmpty() )
	{
		printf("Stack Underflow\n");
		slink();
	}
	return sltop->info;
}/*End of peek() */

int slisEmpty()
{
	if(sltop == NULL)
		return 1;
	else
		return 0;
}/*isEmpty()*/


void sldisplay()
{
	struct stack *ptr;
	ptr=sltop;
	if(slisEmpty())
	{
		printf("Stack is empty\n");
		return;
	}
	printf("Stack elements :\n\n");
	while(ptr!=NULL)
	{
		printf(" %d\n",ptr->info);
		ptr=ptr->link;
	}
	printf("\n");
}/*End of display()*/
