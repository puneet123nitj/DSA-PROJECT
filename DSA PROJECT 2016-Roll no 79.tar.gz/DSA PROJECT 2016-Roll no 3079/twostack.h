#include<stdio.h>
int push1(int);
int pop1();
int display1(int);
int top1=-1;
int max=10;
int top2=10;
int a[10];
int isempty1();
int isfull1();
sdouble()
{
    int k,item;
while(1)
{
printf("1.push in stack 1\n2.pop in stack 1\n3.display stack 1\n4.push in stack 2.\n5.pop in stack 2\n6.display stack 2\n7.for another option\n");
scanf("%d",&k);
switch(k)
{
case 1:
printf("enter the element\n");
scanf("%d",&item);
push1(item);
break;

case 2:
    if(isempty1())
    {
        printf("stack is empty\n");
        break;
    }
printf("element removed is %d\n",pop1());
break;

case 3:

display1(top1);
break;

case 4:

printf("enter the element\n");
scanf("%d",&item);
push2(item);
break;

case 5:

 if(isempty2())
    {
        printf("stack is empty\n");
        break;
    }
printf("element removed is %d\n",pop2());
break;



case 6:

display2(top2);
break;

case 7:
stack1();
break;}
system("pause");
system("cls");}}
int push1(int item)
{
if(!isfull1())
{
top1++;
a[top1]=item;
return 0;
}
else
{
printf("stack1 is full\n");
return;
}
}
int isfull1()
{
if(top1==top2-1)
return 1;
else
return 0;
}
int isempty1()
{
if(top1==-1)
return 1;
else
return 0;
}
int pop1()
{int i;
if(!isempty1())
{i=a[top1];
top1--;
return i;
}}
int display1(int i)
{
    if(isempty1())
    {
        printf("stack1 is empty\n");
        return;
    }
int j;
for(j=i;j>=0;j--)
printf("%d\n",a[j]);
}
 int isfull2()
 {
 if(top2==top1+1)
 return 1;
 else
 return 0;
 }


 int push2(int item)
{
if(!isfull2())
{
top2--;
a[top2]=item;
return 0;
}
else
{
printf("stack2 is full\n");
return;
}
}


int isempty2()
{
int item;
if(top2==max)
return 1;
else
return 0;
}


int display2(int i)
{
    if(isempty2())
    {
        printf("stack2 is empty\n");
        return;
    }
int j;
for(j=i;j<max;j++)
printf("%d\n",a[j]);
}
int pop2()
{
int i;
if(!isempty2())
{i=a[top2];
top2++;
return i;
printf("\n\n%d\n\n",i);
}
}
