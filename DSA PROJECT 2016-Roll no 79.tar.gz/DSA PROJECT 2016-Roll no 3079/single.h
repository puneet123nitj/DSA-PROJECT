#include<stdio.h>
#include<stdlib.h>

struct single
{
	int info;
	struct single *link;
};

struct single *screate_list(struct single *start1);
void sdisplay(struct single *start1);
void scount(struct single *start1);
void ssearch(struct single *start1,int data1);
struct single *saddatbeg(struct single *start1,int data1);
struct single *saddatend(struct single *start1,int data1);
struct single *saddafter(struct single *start1,int data1,int item1);
struct single *saddbefore(struct single *start1,int data1,int item1 );
struct single *saddatpos1(struct single *start1,int data1,int pos1);
struct single *sdel(struct single *start1,int data1);
struct single *sreverse(struct single *start1);
struct single* sselectionsort(struct single*start1);
slink()
{
	struct single *start1=NULL;
	int choice,data1,item1,pos1;

	while(1)
	{
		printf("1.Create List\n");
		printf("2.Display\n");
		printf("3.Count\n");
		printf("4.Search\n");
		printf("5.Add to empty list / Add at beginning\n");
		printf("6.Add at end\n");
		printf("7.Add after single\n");
		printf("8.Add before single\n");
		printf("9.Add at pos1ition\n");
		printf("10.Delete\n");
		printf("11.Reverse\n");
		printf("12.for another option\n\n");
		printf("13.for sorting\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		 case 1:
			start1=screate_list(start1);
			break;
		 case 2:
			sdisplay(start1);
			break;
		 case 3:
			scount(start1);
			break;
		 case 4:
			printf("Enter the element to be searched : ");
			scanf("%d",&data1);
			ssearch(start1,data1);
			break;
		 case 5:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data1);
			start1=saddatbeg(start1,data1);
			break;
		 case 6:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data1);
			start1=saddatend(start1,data1);
			break;
		 case 7:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data1);
			printf("Enter the element after which to insert : ");
			scanf("%d",&item1);
			start1=saddafter(start1,data1,item1);
			break;
		 case 8:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data1);
			printf("Enter the element before which to insert : ");
			scanf("%d",&item1);
			start1=saddbefore(start1,data1,item1);
			break;
		 case 9:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data1);
			printf("Enter the pos1ition at which to insert : ");
			scanf("%d",&pos1);
			start1=saddatpos1(start1,data1,pos1);
			break;
		 case 10:
			printf("Enter the element to be deleted : ");
			scanf("%d",&data1);
			start1=sdel(start1, data1);
			break;
		 case 11:
			start1=sreverse(start1);
			break;
		 case 12:
			 list1();
			 break;
			 case 13:
             start1=sselectionsort(start1);
             break;
		 default:
			 printf("Wrong choice\n");
		}/*End of switch */
		system("pause");system("pause");
    system("cls");

	}/*End of while */
}/*End of main()*/

struct single *screate_list(struct single *start1)
{
	int i,n,data1;
	printf("Enter the number of singles : ");
	scanf("%d",&n);
	start1=NULL;
	if(n==0)
		return start1;

	printf("Enter the element to be inserted : ");
	scanf("%d",&data1);
	start1=saddatbeg(start1,data1);

	for(i=2;i<=n;i++)
	{
		printf("Enter the element to be inserted : ");
		scanf("%d",&data1);
		start1=saddatend(start1,data1);
	}
	return start1;
}/*End of create_list()*/

void sdisplay(struct single *start1)
{
	struct single *p;
	if(start1==NULL)
	{
		printf("List is empty\n");
		return;
	}
	p=start1;
	printf("List is :\n");
	while(p!=NULL)
	{
		printf("%d ",p->info);
		p=p->link;
	}
	printf("\n\n");
}/*End of display() */

void scount(struct single *start1)
{
	struct single *p;
	int cnt=0;
	p=start1;
	while(p!=NULL)
	{
		p=p->link;
		cnt++;
	}
	printf("Number of elements are %d\n",cnt);
}/*End of count() */

void ssearch(struct single *start1,int item1)
{
	struct single *p=start1;
	int pos1=1;
	while(p!=NULL)
	{
		if(p->info==item1)
		{
			printf("item1 %d found at pos1ition %d\n",item1,pos1);
			return;
		}
		p=p->link;
		pos1++;
	}
	printf("item1 %d not found in list\n",item1);
}/*End of search()*/

struct single *saddatbeg(struct single *start1,int data1)
{
	struct single *tmp;
	tmp=(struct single *)malloc(sizeof(struct single));
	tmp->info=data1;
	tmp->link=start1;
	start1=tmp;
	return start1;
}/*End of addatbeg()*/

struct single *saddatend(struct single *start1,int data1)
{
	struct single *p,*tmp;
	tmp=(struct single *)malloc(sizeof(struct single));
	tmp->info=data1;
	p=start1;
	while(p->link!=NULL)
		p=p->link;
	p->link=tmp;
	tmp->link=NULL;
	return start1;
}/*End of addatend()*/

struct single *saddafter(struct single *start1,int data1,int item1)
{
	struct single *tmp,*p;
	p=start1;
	while(p!=NULL)
	{
		if(p->info==item1)
		{
			tmp=(struct single *)malloc(sizeof(struct single));
			tmp->info=data1;
			tmp->link=p->link;
			p->link=tmp;
			return start1;
		}
		p=p->link;
	}
	printf("%d not present in the list\n",item1);
	return start1;
}/*End of addafter()*/

struct single *saddbefore(struct single *start1,int data1,int item1)
{
	struct single *tmp,*p;
	if(start1==NULL )
	{
		printf("List is empty\n");
		return start1;
	}
	/*If data1 to be inserted before first single*/
	if(item1==start1->info)
	{
		tmp=(struct single *)malloc(sizeof(struct single));
		tmp->info=data1;
		tmp->link=start1;
		start1=tmp;
		return start1;
	}
	p=start1;
	while(p->link!=NULL)
	{
		if(p->link->info==item1)
		{
			tmp=(struct single *)malloc(sizeof(struct single));
			tmp->info=data1;
			tmp->link=p->link;
			p->link=tmp;
			return start1;
		}
		p=p->link;
	}
	printf("%d not present in the list\n",item1);
	return start1;
}/*End of addbefore()*/

struct single *saddatpos1(struct single *start1,int data1,int pos1)
{
	struct single *tmp,*p;
	int i;
	tmp=(struct single *)malloc(sizeof(struct single));
	tmp->info=data1;
	if(pos1==1)
	{
		tmp->link=start1;
		start1=tmp;
		return start1;
	}
	p=start1;
	for(i=1; i<pos1-1 && p!=NULL; i++)
		p=p->link;
	if(p==NULL)
		printf("There are less than %d elements\n",pos1);
	else
	{
		tmp->link=p->link;
		p->link=tmp;
	}
	return start1;
}/*End of addatpos1()*/

struct single *sdel(struct single *start1,int data1)
{
	struct single *tmp,*p;
	if(start1==NULL)
	{
		printf("List is empty\n");
		return start1;
	}
	/*Deletion of first single*/
	if(start1->info==data1)
	{
		tmp=start1;
		start1=start1->link;
		free(tmp);
		return start1;
	}
	/*Deletion in between or at the end*/
	p=start1;
	while(p->link!=NULL)
	{
		if(p->link->info==data1)
		{
			tmp=p->link;
			p->link=tmp->link;
			free(tmp);
			return start1;
		}
		p=p->link;
	}
	printf("Element %d not found\n",data1);
	return start1;
}/*End of del()*/

struct single *sreverse(struct single *start1)
{
	struct single *prev, *ptr, *next;
	prev=NULL;
   	ptr=start1;
	while(ptr!=NULL)
	{
		next=ptr->link;
		ptr->link=prev;
		prev=ptr;
		ptr=next;
	}
	start1=prev;
	return start1;
}/*End of reverse()*/
struct single*sselectionsort(struct single*start1)

{int swap;
    struct single*p,*q;
for(p=start1;p->link!=NULL;p=p->link)
{for(q=p->link;q!=NULL;q=q->link)
{if(p->info>q->info)
swap=p->info;
p->info=q->info;
q->info=swap;}}};

