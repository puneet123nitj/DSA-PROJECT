#include<stdio.h>
stack1()
{int choicestack;
while(1)
{
printf("1-> for array stack\n") ;
printf("2-> for link stack\n");
printf("3-> for double stack\n");
printf("4-> for polish notation\n");
printf("5-> for another option\n");
printf("enter your choice =");
scanf("%d",&choicestack);
switch(choicestack)
{
case 1:
    s();
    break;
case 2:
    s1link();
    break;
case 3:
    sdouble();
    break;
case 4:
    polish();
    break;
case 5:
    main();
    break;}
    system("pause");
    system("cls");}}
