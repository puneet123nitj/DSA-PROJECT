
#include<stdio.h>
int partition(int ar[],int low,int high);
void quick(int ar[],int low,int high);
quick1()
{
  int n,i,j,ar[100];
  printf("enter the size of array\n");
  scanf("%d",&n);

  printf("enter the elements of array\n");
  for(i=0;i<n;i++)
  scanf("%d",&ar[i]);
quick(ar,0,n-1);
for(i=0;i<n;i++)
    printf("%d\n",ar[i]);


system("pause");
   system("cls");
   sort1();
return 0;


}

void quick(int ar[],int low,int high)
{int parti;
if(low>=high)
    return;
parti=partition(ar,low,high);
quick(ar,low,parti-1);
quick(ar,parti+1,high);}

int partition(int ar[],int low,int high)
{int i,j,temp,pivot;
pivot=ar[low];;
i=low+1;
j=high;
while(i<=j)
{while((pivot>ar[i])&&(i<high))
    i++;
    while(ar[j]>pivot)
        j--;
    if(i<j)
    {temp=ar[i];
    ar[i]=ar[j];
    ar[j]=temp;
    i++;
    j--;}
    else
        i++;

}
ar[low]=ar[j];
ar[j]=pivot;
return j;

}

