#include <stdio.h>
#include <stdlib.h>

typedef enum {false,true} boolean;

struct thred *tin_succ(struct thred *p);
struct thred *tin_pred(struct thred *p);
struct thred *tinsert(struct thred *root, int ikey);
struct thred *tdel(struct thred *root, int dkey);
struct thred *tcase_a(struct thred *root, struct thred *par,struct thred *ptr);
struct thred *tcase_b(struct thred *root,struct thred *par,struct thred *ptr);
struct thred *tcase_c(struct thred *root, struct thred *par,struct thred *ptr);

void tinorder( struct thred *root);
void tpreorder( struct thred *root);

struct thred
{
	struct thred *left;
	boolean lthread;
	int info;
	boolean rthread;
	struct thred *right;
};

threded( )
{
	int choice,num;
	struct thred *root=NULL;

	while(1)
	{
		printf("\n");
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Inorder Traversal\n");
		printf("4.Preorder Traversal\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		 case 1:
			printf("Enter the number to be inserted : ");
			scanf("%d",&num);
			root = tinsert(root,num);
			break;
		 case 2:
			printf("Enter the number to be deleted : ");
			scanf("%d",&num);
			root = tdel(root,num);
			break;
		 case 3:
			tinorder(root);
			break;
		 case 4:
			tpreorder(root);
			break;
		 case 5:
			 tree1();
			 break;
		 default:
			printf("Wrong choice\n");
		}
	system("pause");
   system("cls");}}
struct thred *tinsert(struct thred *root, int ikey)
{
	struct thred *tmp,*par,*ptr;

	int found=0;

	ptr = root;
	par = NULL;

	while( ptr!=NULL )
	{
		if( ikey == ptr->info)
		{
			found =1;
			break;
		}
		par = ptr;
		if(ikey < ptr->info)
		{
			if(ptr->lthread == false)
				ptr = ptr->left;
			else
				break;
		}
		else
		{
			if(ptr->rthread == false)
				ptr = ptr->right;
			else
				break;
		}
	}

	if(found)
		printf("Duplicate key");
	else
	{

		tmp=(struct thred *)malloc(sizeof(struct thred));
		tmp->info=ikey;
		tmp->lthread = true;
		tmp->rthread = true;
		if(par==NULL)
		{
			root=tmp;
			tmp->left=NULL;
			tmp->right=NULL;
		}
		else if( ikey < par->info )
		{
			tmp->left=par->left;
			tmp->right=par;
			par->lthread=false;
			par->left=tmp;
		}
		else
		{
			tmp->left=par;
			tmp->right=par->right;
			par->rthread=false;
			par->right=tmp;
		}
	}
	return root;
}/*End of insert( )*/

struct thred *tdel(struct thred *root, int dkey)
{
	struct thred *par,*ptr;

	int found=0;

	ptr = root;
	par = NULL;

	while( ptr!=NULL)
	{
		if( dkey == ptr->info)
		{
			found =1;
			break;
		}
		par = ptr;
		if(dkey < ptr->info)
		{
			if(ptr->lthread == false)
				ptr = ptr->left;
			else
				break;
		}
		else
		{
			if(ptr->rthread == false)
				ptr = ptr->right;
			else
				break;
		}
	}

	if(found==0)
		printf("dkey not present in tree");
	else if(ptr->lthread==false && ptr->rthread==false)/*2 children*/
		root = tcase_c(root,par,ptr);
	else if(ptr->lthread==false )/*only left child*/
        root = tcase_b(root, par,ptr);
	else if(ptr->rthread==false)/*only right child*/
        root = tcase_b(root, par,ptr);
	else /*no child*/
		root = tcase_a(root,par,ptr);
	return root;
}/*End of del( )*/

struct thred *tcase_a(struct thred *root, struct thred *par,struct thred *ptr )
{
	if(par==NULL) /*root thred to be deleted*/
		root=NULL;
	else if(ptr==par->left)
	{
		par->lthread=true;
		par->left=ptr->left;
	}
	else
	{
		par->rthread=true;
		par->right=ptr->right;
	}
	free(ptr);
	return root;
}/*End of case_a( )*/

struct thred *tcase_b(struct thred *root,struct thred *par,struct thred *ptr)
{
	struct thred *child,*s,*p;

	/*Initialize child*/
	if(ptr->lthread==false)
		child=ptr->left;
	else
		child=ptr->right;


	if(par==NULL )
		root=child;
	else if( ptr==par->left)
		par->left=child;
	else
		par->right=child;

	s=tin_succ(ptr);
	p=tin_pred(ptr);

	if(ptr->lthread==false) /*if ptr has left subtree */
			p->right=s;
	else
	{
		if(ptr->rthread==false) /*if ptr has right subtree*/
			s->left=p;
	}

	free(ptr);
	return root;
}
struct thred *tcase_c(struct thred *root, struct thred *par,struct thred *ptr)
{
	struct thred *succ,*parsucc;
	parsucc = ptr;
	succ = ptr->right;
	while(succ->left!=NULL)
	{
		parsucc = succ;
		succ = succ->left;
	}

	ptr->info = succ->info;

	if(succ->lthread==true && succ->rthread==true)
		root = tcase_a(root, parsucc,succ);
	else
		root = tcase_b(root, parsucc,succ);
	return root;
}
struct thred *tin_succ(struct thred *ptr)
{
	if(ptr->rthread==true)
		return ptr->right;
	else
	{
		ptr=ptr->right;
		while(ptr->lthread==false)
			ptr=ptr->left;
		return ptr;
	}
}
struct thred *tin_pred(struct thred *ptr)
{
	if(ptr->lthread==true)
		return ptr->left;
	else
	{
		ptr=ptr->left;
		while(ptr->rthread==false)
			ptr=ptr->right;
		return ptr;
	}
}

void tinorder( struct thred *root)
{
	struct thred *ptr;
	if(root == NULL )
	{
		printf("Tree is empty");
		return;
	}

	ptr=root;
	/*Find the leftmost thred */
	while(ptr->lthread==false)
		ptr=ptr->left;

	while( ptr!=NULL )
	{
		printf("%d ",ptr->info);
		ptr=tin_succ(ptr);
	}
}

void tpreorder(struct thred *root )
{
	struct thred *ptr;
	if(root==NULL)
	{
		printf("Tree is empty");
		return;
	}
	ptr=root;

	while(ptr!=NULL)
	{
		printf("%d ",ptr->info);
		if(ptr->lthread==false)
			ptr=ptr->left;
		else if(ptr->rthread==false)
			ptr=ptr->right;
		else
		{
			while(ptr!=NULL && ptr->rthread==true)
				ptr=ptr->right;
			if(ptr!=NULL)
				ptr=ptr->right;
		}
	}
}





