#include<stdio.h>
sort1()
{int choicesort;
while(1)
{
printf("1-> for bubble sort\n") ;
printf("2-> for selection sort\n");
printf("3-> for insertion sort\n");
printf("4-> for merge sort\n");
printf("5-> for quick sort\n");
printf("6-> for heapsort\n");
printf("7-> for another option\n");
printf("enter your choice =");
scanf("%d",&choicesort);
switch(choicesort)
{
case 1:
    bubble();
    break;
case 2:
    selection();
    break;
case 3:
    insertion();
    break;
case 4:
    merge1();
    break;
case 5:
    quick1();
    break;
case 6:
    heapsort();
    break;
case 7:
    main();
    break;}
    system("pause");
    system("cls");}}
